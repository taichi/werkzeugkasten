package jp.aonir.fuzzyxml.util;

import jp.aonir.fuzzyxml.FuzzyXMLNode;

public interface NodeFilter {
	
	public boolean filter(FuzzyXMLNode node);
	
}
