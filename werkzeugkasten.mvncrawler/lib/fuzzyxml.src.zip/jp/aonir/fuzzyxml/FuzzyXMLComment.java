package jp.aonir.fuzzyxml;

public interface FuzzyXMLComment extends FuzzyXMLNode {
	
	public String getValue();
	
}
