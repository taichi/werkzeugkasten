package sdloader;

import java.util.ArrayList;
import java.util.List;

public class StartUpList {

	public static List<String> startUpList = new ArrayList<String>();
}
